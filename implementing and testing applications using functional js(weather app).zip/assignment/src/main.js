import {fetchcitydata} from './model/citymodel';
import {rendercity} from './presenters/citypresenter';

document.querySelector('.js-search-city')
.addEventListener('click',searchcity);

function searchcity()
{
	const textfield=document.querySelector('.js-city-field');
	const city=textfield.value;
	fetchcitydata(city).then(response=>rendercity(response))
		
	textfield.value='';
}