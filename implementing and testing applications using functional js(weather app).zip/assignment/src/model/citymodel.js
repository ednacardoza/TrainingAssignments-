import {fetchweather} from './weathermodel';
import {fetchtimezone} from './timezonemodel';
export const fetchcitydata=async(city)=>{
	const weatherresponse=await fetchweather(city);
	const timestamp=weatherresponse.today.dt;
	const {lat,lon}=weatherresponse.today.coord;
	const timezoneresponse=await fetchtimezone(timestamp,lat,lon);
	return{
		today:weatherresponse.today,
		forecast:weatherresponse.forecast,
		timezoneresponse
	}
};