import axios from 'axios';
import {getOpenWeatherMapUrl} from '../utils/endpoints.js';
const todaysweatherurl=getOpenWeatherMapUrl('weather')({units:'metric'});
const forecastrurl=getOpenWeatherMapUrl('forecast')({units:'metric',cnt:16});

const gettodaysweather=async(city)=>axios.get(todaysweatherurl(city));
const getweatherforecast=async(city)=>axios.get(forecastrurl(city));
export const fetchweather=async(city)=>{
	const[today,forecast]=await Promise.all([
		gettodaysweather(city),
		getweatherforecast(city)]);
	return {today:today.data,forecast:forecast.data};
}

