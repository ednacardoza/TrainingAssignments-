import axios from 'axios';
import {gettimezoneurl} from '../utils/endpoints.js';
export const fetchtimezone=async(timestamp,lat,lon)=>{
	const response=await axios.get(gettimezoneurl(lat,lon)(timestamp));
	return response.data;
};