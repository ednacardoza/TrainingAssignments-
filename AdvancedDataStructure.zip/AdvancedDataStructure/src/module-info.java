module AdvancedDataStructure {
}