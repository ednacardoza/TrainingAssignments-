package mainassignment;



import java.util.Arrays;
import java.util.Comparator;

public class Quicksort_1 {
	public static <E> void quicksort(E a[],int start,int end,Comparator<E> comparator){
		if(end-start<=0) {
			return;
		}
		/*
		 * int pivot=(int)((end-start)*Math.random())+start; swap(a,pivot,end-1);
		 */
		int i=start;
		int j=end-1;
		boolean flag=true;
		while(i<j)
		{
			if(comparator.compare(a[i], a[j])>0)
			{
				swap(a,i,j);
				flag=!flag;	
			}
			else {
				if(flag)
				{
					i++;
				}
				else
				{
					j--;
				}
			}
		}
		quicksort(a,start,i,comparator);
		quicksort(a,i+1,end,comparator);
	}
	public static <E> void quicksort(E a[],Comparator<E> comparator) {
		quicksort(a,0,a.length,comparator);
	}
	public static <E> void swap(E a[],int i,int j) {
		if(i==j)
		{
			return;
		}
		E temp=a[i];
		a[i]=a[j];
		a[j]=temp;
	}
	public static void main(String[] args) {
		String a[]= {"blue","red","yellow","blue","red","yellow","red"};
		quicksort(a,(i,j)->i.compareTo(j));
		System.out.println(Arrays.toString(a));
	}

}

