package mainassignment;
public class TREE {
	Node root;

	static class Node{
		int key;
		Node left;
		Node right;
		Node(int item){
			key=item;
			left=right=null;
		}	
	}
	TREE(){
		root=null;
	}
	void printnodes() {
		int h=height(root);
		int i;
		System.out.println("Height: "+h);
		for(i=1;i<=h;i++)
		{
			printlevel(root,i);
		}
	}
	int height(Node root) {
		if(root==null) {
			return 0;
		}
		else {
			int lefth=height(root.left);
			int righth=height(root.right);
			System.out.println(righth);
			if(lefth>righth)
				return (lefth+1);
			return (righth+1);
		}
		
	}
	void printlevel(Node root, int level) {
		if (root == null) 
            return; 
        if (level == 1) 
            System.out.print(root.key + " "); 
        else if (level > 1) 
        { 
        	printlevel(root.left, level-1); 
        	printlevel(root.right, level-1); 
        } 
	}
	public static void main(String[] args) {
		TREE tree=new TREE();
		tree.root=new Node(1);
		tree.root.left=new Node(2);
		tree.root.right=new Node(3);
		tree.root.left.left=new Node(4);
		tree.root.left.right=new Node(5);
		tree.root.right.left=new Node(6);
		tree.root.right.right=new Node(7);
		tree.root.right.right.right=new Node(9);

	System.out.println(tree.height(tree.root));






		
	}

}

