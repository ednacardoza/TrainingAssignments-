package mainassignment;


import java.util.*;
public class Hashing {
	static void createHashMap(int a[]) {
	HashMap<Integer,Integer> hmap=new HashMap<Integer,Integer>();
	for(int i=0;i<a.length;i++) {
		Integer c = hmap.get(a[i]);
        if (hmap.get(a[i]) == null) {
            hmap.put(a[i], 1);
        } else {
            hmap.put(a[i], ++c);
        }
    }
    System.out.println(hmap);
}
	  public static void main(String[] args) {
	        int arr[] = { 2, 34, 878, 98, 234, 8 };
	        createHashMap(arr);
	  }

	}


