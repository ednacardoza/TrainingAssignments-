function appendToDiv(div,amount,elements) {
	let i=0;
	// body...
for (let i=1;i<amount;i++){
   div.innerHTML +='<div>${elements[i]}</div>';

   const newElement = document.createElement('div');
   newElement.innerHTML = elements[i];

   div.appendChild(newElement);
}
	}

function getUSACities(){


}

function start()}{
	getUSACities().then(cities =>{
		const AMOUNT_OF_ELEMENTS =1000;

		const startTime = performance.now();

		appendToDiv(document.body.AMOUNT_OF_ELEMENTS,cities);

		const endTime =performance.now();

		document
		.getElementById('time')
		.innerHTML = '${Math.round(endTime - startTime)}milliseconds';
	});
}