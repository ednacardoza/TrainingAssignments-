package com.example.pkg;

import java.util.List;

public class Employee {
	private int  id;
	private String  n;
	private String  gender;
	private List<String> adress;
	public Employee() {
		
	}
	public Employee(int id, String n, String gender, List<String> adress) {
		super();
		this.id = id;
		this.n = n;
		this.gender = gender;
		this.adress = adress;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getN() {
		return n;
	}
	public void setN(String n) {
		this.n = n;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public List<String> getAdress() {
		return adress;
	}
	public void setAdress(List<String> adress) {
		this.adress = adress;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + n + ", gender=" + gender + ", address=" + adress + "]";
	}
	
	
	
}
