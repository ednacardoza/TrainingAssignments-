package com.example.pkg;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class ApplicationStart {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Beans.xml");
		Point p = (Point)applicationContext.getBean("Point10");
		
		System.out.println(p.getX());
		System.out.println(p.getY());
		ThreeDPoint q = (ThreeDPoint)applicationContext.getBean("Point3D");
		System.out.println(q.getX());
		System.out.println(q.getY());
		System.out.println(q.getZ());
		
		Calculator cal= (Calculator) applicationContext.getBean("calc");
		
		System.out.println(cal.add());
		System.out.println(cal.divide());
		System.out.println(cal.multiply());
		System.out.println(cal.subtract());
		
		
		Animal any =(Animal) applicationContext.getBean("ani");
		
		System.out.println(any.getHeight());
		System.out.println(any.getName());
		System.out.println(any.getWeight());
		Animal ann =(Animal) applicationContext.getBean("anim");
		System.out.println(ann.getValidator());
	
		System.out.println(any.getColor().getColorName());
		System.out.println(any.getColor().getColorId());
		//System.out.println(any.getWeight());
		
		System.out.println(any.getColor().getColorName());
		System.out.println(any.getColor().getColorId());
		
		Animal gir =(Animal) applicationContext.getBean("nam");
		System.out.println(gir.getColor().getColorName());
		System.out.println(gir.getColor().getColorId());
		
		
	Color col =(Color) applicationContext.getBean("gold");
	System.out.println(col.getColorName());
	System.out.println(col.getColorId());
	
	/*
	 * Animal sizi =(Animal) applicationContext.getBean("siz");
	 * System.out.println(sizi.getSize().getWeight());
	 * System.out.println(sizi.getSize().getHeight());
	 */
	
	
		
		
	Employee e=(Employee) applicationContext.getBean("employee");
	System.out.println(e);
		
	
	SiCalculation calc=(SiCalculation) applicationContext.getBean("inte");
	float i=calc.getInterest();
	float t=calc.getTime();
	float pr=calc.getPrincipal();
	
	System.out.println("Simple interest: "+(pr*t*i)/100);
		


	}

}
