package com.example.pkg;

public class SiCalculation {
	private float principal;
	private float interest;
	private float time;
	SiCalculation()
	{
		
	}
	public SiCalculation(float principal, float interest, float time) {
		super();
		this.principal = principal;
		this.interest = interest;
		this.time = time;
	}
	public float getPrincipal() {
		return principal;
	}
	public void setPrincipal(float principal) {
		this.principal = principal;
	}
	public float getInterest() {
		return interest;
	}
	public void setInterest(float interest) {
		this.interest = interest;
	}
	public float getTime() {
		return time;
	}
	public void setTime(float time) {
		this.time = time;
	}
	
}
