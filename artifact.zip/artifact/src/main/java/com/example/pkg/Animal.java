package com.example.pkg;

public class Animal {
	private double weight ;
	private float height ;
	private String name;
	private Color Color;
	//private Size Size;
	private String validator;
	
	
	





	public String getValidator() {
		return validator;
	}






	public void setValidator(String validator) {
		this.validator = validator;
	}






	public Animal() {
		
	}
	
	
	
	
	

	public Animal(double weight, float height, String name, com.example.pkg.Color color) {
		super();
		this.weight = weight;
		this.height = height;
		this.name = name;
		Color = color;
		//Size = size;
	}






	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}






	public float getHeight() {
		return height;
	}






	public void setHeight(float height) {
		this.height = height;
	}






	public String getName() {
		return name;
	}






	public void setName(String name) {
		this.name = name;
	}






	public Color getColor() {
		return Color;
	}






	public void setColor(Color color) {
		Color = color;
	}






	/*
	 * public Size getSize() { return Size; }
	 * 
	 * 
	 * 
	 * 
	 * 
	 * 
	 * public void setSize(Size size) { Size = size; }
	 */



	
	
}



