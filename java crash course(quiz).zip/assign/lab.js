// question.js
questions = new Array();
questions.push("who played punky browster in the early 80's TV sitcom of same name?");
questions.push("for over 40 years this man has been big bird's puppeteer :");
questions.push("singer celine dion is a native of this country :");
questions.push("ronald reagan was inaugrated for his first term in which year? ");
questions.push("this major league baseball team has won more series than any other :");

questionOneAnswers = new Array("sloeil moon frye","meeno poolous","heather locklear","molly ringwald");
questionTwoAnswers = new Array("jim henson","art van delay","caroll spinney","bob keeshan");
questionThreeAnswers = new Array("united states","israel","france","canada");
questionFourAnswers = new Array("1978","1980","1981","1985");
questionFiveAnswers = new Array("new york mets","toronto blue jays","la dodgers","new york yankees");
correctAnswerIndexes = new Array(0,2,3,2,3);