package assignments;

import java.io.IOException;

public class Prog17 {

	public static void main(String[] args) throws IOException {
		int x=20;
		int y=0;
		try
        { 
            
            int sum = x / y;
         } 
        catch(Exception e) 
        { 
            System.out.println(e); 
        } 
        finally
        { 
            System.out.println("x= "+x+" y= "+y+" bye!!!"); 
        } 
	}

}
