package assignments;

public class ImportantDates implements Comparable<ImportantDates> {
	int birthdate;
	int hiredate;
	int marraigedate;
	public ImportantDates(int birthdate, int hiredate, int marraigedate) {
		super();
		this.birthdate = birthdate;
		this.hiredate = hiredate;
		this.marraigedate = marraigedate;
	}
	public int getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(int birthdate) {
		this.birthdate = birthdate;
	}
	public int getHiredate() {
		return hiredate;
	}
	public void setHiredate(int hiredate) {
		this.hiredate = hiredate;
	}
	public int getMarraigedate() {
		return marraigedate;
	}
	public void setMarraigedate(int marraigedate) {
		this.marraigedate = marraigedate;
	}
	  public int compareTo(ImportantDates d) {
		  return d.birthdate- this.birthdate;
	    }
	@Override
	public String toString() {
		return "ImportantDates [birthdate=" + birthdate + ", hiredate=" + hiredate + ", marraigedate=" + marraigedate
				+ "]";
	}




}
