package assignments;

public class Prog5 {
	public static void main(String[] args) {
		byte b=100;
		short s=123;
		int i=-1234;
		long l=1234567891;
		float f=1234.67f;
		double d=5677868787d;
		boolean bo=true;
		char c=90;
		System.out.println("byte:"+b);
		System.out.println("short:"+s);
		System.out.println("integer:"+i);
		System.out.println("long:"+l);
		System.out.println("float:"+f);
		System.out.println("double:"+d);
		System.out.println("boolean:"+bo);
		System.out.println("character:"+c);
		
		int a=23456;
		byte by=(byte)a;
		System.out.println("after conversion from int to byte: "+by);







		
		
	}
}
