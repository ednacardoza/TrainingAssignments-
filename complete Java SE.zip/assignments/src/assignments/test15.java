package assignments;

public class test15 {
	public static void main(String[] args) {
		Prog15 p=new Prog15();
		p.arraylisteg();
		System.out.println();
		p.treeseteg();
		System.out.println();
		p.hashseteg();
		System.out.println();
		p.hashmapeg();
		System.out.println();
		p.queueeg();
	}

}
