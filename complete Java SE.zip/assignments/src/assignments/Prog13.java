package assignments;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class Prog13 {

	public static void main(String[] args) {
		LocalDate dob=LocalDate.of(1997, 07, 15);
		DateTimeFormatter format = DateTimeFormatter.ofPattern("MM/dd/yyyy");
		LocalDate date=LocalDate.now();
		System.out.println("Date: "+date);
		LocalTime time=LocalTime.now();
		System.out.println("Time: "+time);
		String d=format.format(date);
		System.out.println("dd/mm/yyyy: "+d);
		Period diff=Period.between(dob, date);
		System.out.println("Age: "+diff.getYears()+" years");
		



	}

}
