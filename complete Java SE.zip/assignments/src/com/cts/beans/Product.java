package com.cts.beans;

public class Product {
	public int code;
	public String name;
	public float price;
	public void display()
	{
		System.out.println("code: "+code);
		System.out.println("name: "+name);
		System.out.println("price: "+price);


	}
	
	

}
