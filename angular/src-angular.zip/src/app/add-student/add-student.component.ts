import { Component, OnInit } from '@angular/core';
import {Student} from "./../student";
import { StudService } from '../stud.service';

@Component({
  selector: 'app-add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {

student:Student=new Student();
	submitted=false;



  constructor(private studService: StudService) { }

  ngOnInit() {
  }
  newStudent():void{
  		this.submitted=false;
  		this.student=new Student();
  
  }


  	save()
  	{
  		this.studService.createStudent(this.student).subscribe(data=>console.log(data),error=>console.log(error));
  		this.student=new Student();
  		
  	}
  	onSubmit()
  	{
  		this.submitted=true;
  		this.save();
  	}
  	
}
