


export class Student {


	id: number;
	firstName: string;
	lastName: string;
    address: string;
  
	
	

}
