import { Injectable } from '@angular/core';
import { HttpClient,HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudService {

private baseUrl = 'http://localhost:8081/api/v1/students'



  constructor(private http: HttpClient,private studService: StudService) { }

    getStudentList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
}
createStudent(student:Object):Observable<Object>{
    return this.http.post(`${this.baseUrl}`,student);
  }



}
