module DesignPatternsDemo {
	requires java.sql;
}