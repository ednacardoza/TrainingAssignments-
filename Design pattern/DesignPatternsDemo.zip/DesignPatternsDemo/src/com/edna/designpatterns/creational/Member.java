package com.edna.designpatterns.creational;

public interface Member {
  void registerMember(String uname);
  void showMember();
}
