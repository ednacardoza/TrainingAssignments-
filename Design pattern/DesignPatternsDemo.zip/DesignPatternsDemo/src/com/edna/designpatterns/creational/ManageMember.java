package com.edna.designpatterns.creational;

public class ManageMember {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//EdnaInternationalMemberFactory factory = new EdnaInternationalMemberFactory();
		
		MemberFactory international = EdnaFactoryProducer.getMemberFactory("International");
		Member member1 = international.subscribe("Lifetime");
		member1.registerMember("Nakamoto Yuta");
		member1.showMember();
		System.out.println("--------------------------------------------------------------------");
		
		Member member2 = international.subscribe("Annual");
		member2.registerMember("Mark Lee");
		member2.showMember();
		System.out.println("--------------------------------------------------------------------");
		
		
		MemberFactory national = EdnaFactoryProducer.getMemberFactory("National");
		Member member3 = national.subscribe("Monthly");
		member3.registerMember("Namazaki Kento");
		member3.showMember();
		System.out.println("--------------------------------------------------------------------");

	}

}
