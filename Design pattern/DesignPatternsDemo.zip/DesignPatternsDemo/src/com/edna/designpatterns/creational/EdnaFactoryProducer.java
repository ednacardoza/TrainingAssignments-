package com.edna.designpatterns.creational;

public class EdnaFactoryProducer {
	public static MemberFactory getMemberFactory(String nationality) {
		MemberFactory memberFactory = null;
		switch(nationality.toUpperCase()) {
		case "NATIONAL" :
			memberFactory = new EdnaNationalMemberFactory();
			break;
		case "INTERNATIONAL" :
			memberFactory = new EdnaInternationalMemberFactory();
			break;
		}
		return memberFactory;
	}

}
