package com.edna.designpatterns.creational;

public class EdnaNationalMemberFactory implements MemberFactory {

	@Override
	public Member subscribe(String subscriptionType) {
		// TODO Auto-generated method stub
		Member member = null;
		if(subscriptionType.equalsIgnoreCase("Monthly")) {
			member = new MonthlyMember();
		}
		return member;
	}

}
