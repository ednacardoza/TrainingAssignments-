package com.edna.designpatterns.creational;


import java.util.Date;








public abstract class Membership implements Member {
	
	public String userId;
	public String userName;
	public  Date startDate;
	public Date endDate;
	public float discountPercentage;
	public String subscriptionType;

	@Override
	public abstract void registerMember(String uname);

	@Override
	public void showMember() {
		// TODO Auto-generated method stub
		System.out.println("UserId: " + this.userId 
				+ "\n userName: " + this.userName
				+ "\n subscriptionType: " + this.subscriptionType
				+ "\n startDate: " + this.startDate
				+ "\n endDate: " + this.endDate
				+ "\n discountpercetage: " + this.discountPercentage
				);

	}
 
	
  
}
