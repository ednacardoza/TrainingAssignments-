package com.edna.designpatterns.creational;

public interface MemberFactory {
	Member subscribe(String subscriptionType);

}
