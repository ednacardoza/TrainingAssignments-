package org;

import java.util.*;
public class Hash {
	  
	  
	 public static void main(String args[]){  
	  //Creating HashSet and adding elements  
	    HashSet<String> set=new HashSet();  
	           set.add("edna");    
	           set.add("roy");    
	           set.add("anson");   
	           set.add("edgar");  
	           set.add("justen");  
	           
	           Iterator<String> itr=set.iterator();  
	           while(itr.hasNext()){  
	            System.out.println(itr.next());  
	           }  
	          
	           
	           HashSet<String> set1=new HashSet<String>();  
	           set1.add("brendan");  
	           set1.add("keyna");  
	           set.addAll(set1);  
	           System.out.println("Updated List: "+set);
	           
	           set.remove("edna");  
	           System.out.println("After invoking remove(object) method: "+set);  
	 }  
	}  




  
             
           
