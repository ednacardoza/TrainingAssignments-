package org;
import java.util.*; 
public class Linkedlist {
	 
	 
	 public static void main(String args[]){  
	  
	  LinkedList<String> al=new LinkedList<String>();  
	  al.add("jhope");  
	  al.add("taeyong");  
	  al.add("mark");  
	  al.add("jaemin");  
      al.add("taehyung");  
      al.add("jimin");  
      al.add("jungkook");  
      al.add("jin");  
      al.add("namjoon");  
      al.add("suga");  
      al.add("yuta");  
      al.add("jackson");  
      al.add("jonghyun");  
      al.add("key"); 
	  
	  Iterator<String> itr=al.iterator();  
	  while(itr.hasNext()){  
	   System.out.println(itr.next());  
	  }  
	  
	  LinkedList<String> al2=new LinkedList<String>();  
      al2.add("kim woo bin");  
      al2.add("lee min ho");  
 
      al.addAll(al2);  
      System.out.println("Updated list : "+al);
      
      al.removeFirst();  
      System.out.println("After first element is removed: "+al); 
      
      al.removeLast();  
      System.out.println("After last element is removed: "+al);  
	 }  
	}  


 

  
   